# Se ejecuta desde la carpeta descomprimida. Los CSV incluidos funcionan offline.
# source("actualizar.R")
# indicadores <- leer_wdi(1990, 2024)
# write.csv(indicadores, "wdi.csv", row.names = FALSE)
# enlaces <- leer_exportaciones(c("CHL", "DEU"), 2023)
# write.csv(enlaces, "exportaciones.csv", row.names = FALSE)

leer_wdi <- function(desde, hasta) {
  muestra <- unique(utils::read.csv("gapminder.csv")[c("iso3", "continent")])
  indicadores <- c(pop = "SP.POP.TOTL", lifeExp = "SP.DYN.LE00.IN",
                   gdpPercap = "NY.GDP.PCAP.PP.KD")
  datos <- WDI::WDI(country = "all", indicator = indicadores, start = desde,
                    end = hasta, extra = TRUE)
  datos <- merge(muestra, datos[c("iso3c", "year", names(indicadores))],
                 by.x = "iso3", by.y = "iso3c", all.x = FALSE)
  panel <- merge(muestra, data.frame(year = seq.int(desde, hasta)), by = NULL)
  panel <- merge(panel, datos, by = c("iso3", "continent", "year"), all.x = TRUE)
  panel$gdp_ppp_2021 <- panel$pop * panel$gdpPercap
  panel[order(panel$iso3, panel$year), ]
}

leer_exportaciones <- function(reportantes, anio) {
  # comtradr::set_primary_comtrade_key() configura la clave de UN Comtrade.
  flujos <- lapply(unique(reportantes), function(iso3) {
    datos <- comtradr::ct_get_data(
      reporter = iso3, partner = "all_countries", flow_direction = "Export",
      commodity_code = "TOTAL", start_date = as.character(anio),
      end_date = as.character(anio), tidy_cols = FALSE
    )
    if (!nrow(datos)) stop("Sin datos de exportaciones para ", iso3, " en ", anio)
    data.frame(year = as.integer(datos$refYear), from = datos$reporterISO,
               to = datos$partnerISO, weight = datos$primaryValue)
  })
  enlaces <- do.call(rbind, flujos)
  enlaces <- subset(enlaces, !is.na(weight) & weight > 0 & from != to)
  stopifnot(!anyDuplicated(enlaces[c("year", "from", "to")]))
  enlaces[order(enlaces$year, enlaces$from, -enlaces$weight), ]
}

# Misma fuente que la animación. wbstats accede a los indicadores del Banco Mundial.
# La descarga devuelve importes brutos en USD y conserva los NA de la fuente.
leer_panel_wbstats <- function(desde = 2007L, hasta = as.integer(format(Sys.Date(), "%Y")) - 1L) {
  universo <- unique(utils::read.csv("gapminder.csv")[c("iso3", "country", "continent")])
  ids <- c("SP.POP.TOTL", "SP.DYN.LE00.IN", "NY.GDP.PCAP.PP.KD", "TX.VAL.MRCH.CD.WT")
  datos <- as.data.frame(wbstats::wb_data(
    indicator = ids, country = "countries_only", start_date = desde, end_date = hasta,
    return_wide = TRUE
  ))
  names(datos)[match(ids, names(datos))] <- c("pop", "lifeExp", "gdpPercap_ppp2021", "exports_usd")
  datos <- datos[c("iso3c", "date", "pop", "lifeExp", "gdpPercap_ppp2021", "exports_usd")]
  names(datos)[1:2] <- c("iso3", "year")
  merge(universo, datos, by = "iso3", sort = TRUE)
}

# Comercio bilateral según tradestatistics v7.1. ITPD-E ofrece pares importador/exportador.
# La fecha debe estar cubierta por la fuente. No confundir año de edición con año del flujo.
leer_pacha <- function(anio = 2020L, importadores = "chl", exportadores = c("arg", "bra")) {
  tradestatistics::ots_create_tidy_data(years = anio, importers = importadores,
                                        exporters = exportadores, table = "itpde_imp_exp")
}
