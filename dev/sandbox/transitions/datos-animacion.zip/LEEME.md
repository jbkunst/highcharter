# Datos de la animación

El corte de población, esperanza de vida y PIB PPA por habitante es 2024. La última observación de esperanza de vida disponible en la copia WDI consultada corresponde a ese año. El PIB PPA usa dólares internacionales constantes de 2021. El PIB total ilustrado resulta de multiplicar habitantes por PIB PPA por habitante.

Las exportaciones de mercancías llegan a 2025. Son dólares estadounidenses corrientes e incluyen el efecto de precios y tipos de cambio. Las líneas, áreas y bandas muestran el valor anual exportado por los mismos países, sumado por continente. La segunda vista del treemap usa el último valor de esas mismas series.

## Cobertura

De las 142 economías de la muestra original de Gapminder, 132 tienen los tres indicadores en 2024 y exportaciones en los 19 años de 2007 a 2025. Se mantienen esas 132 en toda la animación. El CSV de exclusiones indica los motivos. En el packed bubble, cada uno de los tres grupos contiene 44 países, ordenados por PIB PPA por habitante en 2024. Las agrupaciones son terciles de la muestra.

| Archivo | Contenido |
|---|---|
| paises_2024.csv | Un registro por país, con ISO3, continente, población, esperanza de vida y PIB PPA por habitante. |
| exportaciones_2007_2025.csv | País × año. Exportaciones de mercancías en USD corrientes. |
| continentes.csv | Suma de las exportaciones de los 132 países por continente y año. |
| excluidos.csv | Economías de la muestra original con indicadores faltantes. |
| bilateral_usa_2025.csv | Diez enlaces dirigidos de bienes entre EE. UU. y cinco socios (Chile, China, Alemania, Australia y Sudáfrica). EE. UU. es el reportante en ambos sentidos. Los datos publicados en millones de USD con un decimal se convierten a USD. Cada fila incluye su fuente. |
| fmi_volumen_comercio.csv | Crecimiento anual del volumen del comercio mundial de bienes, 2018–2025, en %. WEO de octubre de 2026, tabla A9, fila Trade in Goods / World Trade / Volume. Sirve como serie alternativa de tasas, para líneas. |
| gapminder.csv y continentes_gapminder.csv | Base histórica del primer prototipo de 1952–2007, separada de WDI. |
| comercio_wits.csv y enlaces_exportaciones.csv | Muestra histórica WITS de 2007 y 2023. Cinco socios principales de cinco reportantes por flujo. Los enlaces recogen exportaciones a países identificados y los faltantes no equivalen a cero. |
| actualizar.R | Funciones para consultar WDI con wbstats o WDI, comercio bilateral con comtradr y las tablas de Pachá con tradestatistics v7. |

Una red o rueda puede leer year, from, to y weight. En el archivo bilateral de EE. UU., weight representa dólares y reported_as distingue la valoración del lado que reporta. No combines totales mundiales con socios, ni sumes los registros espejo de una misma operación.

## Fuentes

- WDI, Banco Mundial. SP.POP.TOTL, SP.DYN.LE00.IN, NY.GDP.PCAP.PP.KD y TX.VAL.MRCH.CD.WT. Copia de datos WDI distribuida por Gapminder (consulta del 15 de noviembre de 2026). https://www.gapminder.org/data/ y https://github.com/open-numbers/ddf--open_numbers--world_development_indicators/tree/master/datapoints
- Organización Mundial del Comercio vía WDI, exportaciones de mercancías. https://data.worldbank.org/indicator/TX.VAL.MRCH.CD.WT
- U.S. Census Bureau, datos de comercio de bienes. URL de consulta en cada registro. https://www.census.gov/foreign-trade/balance/
- Fondo Monetario Internacional, WEO, tabla A9 de octubre de 2026. Las tasas incluidas terminan antes de las columnas de proyecciones 2026–2027. https://www.imf.org/-/media/files/publications/weo/2026/october/english/tablea.pdf
- Pachá, wbstats. https://pacha.dev/blog/2026/08/28/wbstats/index.html
- Pachá, tradestatistics. En v7 usa USITC y ofrece desglose por industria. La edición 2025 de ITPD-E cubre 1986–2023. https://cran.r-project.org/web/packages/tradestatistics/news/news.html y https://www.usitc.gov/data/gravity/gravity_portal_itpd_e
- Gapminder histórico. https://jennybc.github.io/gapminder/reference/gapminder.html
